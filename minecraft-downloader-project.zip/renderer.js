document.addEventListener('DOMContentLoaded', async () => {
    const tabs = {
      downloader: document.getElementById('downloader'),
      archive: document.getElementById('archive'),
      backup: document.getElementById('backup'),
      stats: document.getElementById('stats'),
      settings: document.getElementById('settings')
    };
    const tabButtons = {
      downloader: document.getElementById('tab-downloader'),
      archive: document.getElementById('tab-archive'),
      backup: document.getElementById('tab-backup'),
      stats: document.getElementById('tab-stats'),
      settings: document.getElementById('tab-settings')
    };
    const consoleEl = document.getElementById('console');
    const progressPanel = document.getElementById('progress-panel');
    const backupProgressPanel = document.getElementById('backup-progress-panel');
    const stopButton = document.getElementById('stop');
    let controller = null;
    let isDownloading = false;
    let translations = {};
  
    // Domyślne ustawienia
    let settings = {
      menuVisible: true,
      devToolsEnabled: false,
      theme: 'dark',
      animations: true,
      speedLimit: '0',
      autoRefresh: false,
      downloadPath: '',
      downloadMode: 'missing',
      analysisMode: false,
      language: 'pl',
      backup: {
        compressZip: true,
        includeLogs: false,
        overwriteOnRestore: true
      }
    };
  
    // Wczytywanie ustawień
    try {
      const fetchedSettings = await window.ipcRenderer.invoke('get-settings');
      console.log('Wczytane ustawienia:', JSON.stringify(fetchedSettings, null, 2));
      if (fetchedSettings) {
        settings = { ...settings, ...fetchedSettings };
        if (!settings.backup) {
          settings.backup = {
            compressZip: true,
            includeLogs: false,
            overwriteOnRestore: true
          };
        }
      } else {
        console.warn('Nie udało się wczytać ustawień, używam domyślnych');
      }
    } catch (err) {
      console.error('Błąd wczytywania ustawień:', err);
    }
  
    // Wczytywanie tłumaczeń przez IPC
    async function loadTranslations() {
      try {
        translations = await window.ipcRenderer.invoke('get-translations', settings.language);
        console.log('Wczytano tłumaczenia:', JSON.stringify(translations, null, 2));
        applyTranslations();
      } catch (err) {
        console.error('Błąd wczytywania tłumaczeń:', err);
        // Fallback na domyślne tłumaczenia (pl)
        translations = {
          app_title: 'Pobieracz Minecraft',
          tab_downloader: 'Pobieralnia',
          tab_archive: 'Archiwum',
          tab_backup: 'Kopie i przywracanie',
          tab_stats: 'Statystyki',
          tab_settings: 'Ustawienia',
          downloader_title: 'Pobieralnia',
          assets_summary: 'Znaleziono 0 unikalnych assetów, łączny rozmiar: 0 MB',
          overall_progress: 'Postęp ogólny: 0%',
          assets_progress: 'Assets: 0/0 MB, 0/0 plików, 0 MB/s',
          libs_progress: 'Biblioteki: 0/0 MB, 0/0 plików, 0 MB/s',
          versions_progress: 'Wersje: 0/0 MB, 0/0 plików, 0 MB/s',
          analysis_mode: 'Tylko policz, nie pobieraj',
          check_assets: 'Sprawdź assetsy',
          check_libraries: 'Sprawdź biblioteki',
          check_manifest: 'Sprawdź manifest',
          check_versions: 'Sprawdź wersje',
          check_all: 'Sprawdź wszystko',
          stop: 'Stop',
          archive_title: 'Archiwum',
          archive_size: 'Rozmiar archiwum: 0 MB',
          filter_all: 'Wszystkie',
          filter_assets: 'Assets',
          filter_libraries: 'Biblioteki',
          filter_versions: 'Wersje',
          search_name: 'Szukaj po nazwie...',
          search_hash: 'Szukaj po hashu...',
          search_size: 'Rozmiar (np. >1MB)...',
          search_version: 'Wersja...',
          refresh_archive: 'Odśwież',
          archive_empty: 'Archiwum jest puste.',
          type: 'Typ',
          name: 'Nazwa',
          status: 'Status',
          size: 'Rozmiar',
          actions: 'Akcje',
          status_posiadane: 'Posiadane',
          status_brak: 'Brak',
          backup_title: 'Kopie i przywracanie',
          backup_progress: 'Postęp: 0 MB / 0 MB, czas: 0 s',
          export_backup: 'Eksport do ZIP',
          import_backup: 'Import z ZIP',
          stats_title: 'Statystyki',
          downloaded_mb: 'Pobrane MB',
          total_assets: 'Liczba assetów',
          total_libraries: 'Liczba bibliotek',
          total_versions: 'Liczba wersji',
          total_time: 'Czas pobierania',
          settings_title: 'Ustawienia',
          general_settings: 'Ogólne',
          menu_visible: 'Widoczność menu',
          dev_tools: 'Narzędzia deweloperskie',
          theme: 'Motyw',
          dark_theme: 'Ciemny',
          light_theme: 'Jasny',
          language: 'Język',
          lang_pl: 'Polski',
          lang_en: 'English',
          download_settings: 'Ustawienia pobierania',
          download_path: 'Ścieżka pobierania',
          speed_limit: 'Limit prędkości (MB/s)',
          download_mode: 'Tryb pobierania',
          mode_missing: 'Tylko brakujące',
          mode_all: 'Wszystkie',
          animations: 'Animacje',
          auto_refresh: 'Auto-odświeżanie archiwum',
          backup_settings: 'Ustawienia kopii zapasowych',
          compress_zip: 'Kompresja ZIP',
          include_logs: 'Uwzględniaj logi',
          overwrite_restore: 'Nadpisz przy przywracaniu',
          logs_settings: 'Logi',
          clear_logs: 'Wyczyść logi',
          close: 'Zamknij',
          modal_default: 'Wystąpił błąd',
          select_all_versions: 'Zaznacz wszystko',
          deselect_all_versions: 'Odznacz wszystko'
        };
        applyTranslations();
      }
    }
  
    function applyTranslations() {
      document.querySelectorAll('[data-i18n]').forEach(element => {
        const key = element.getAttribute('data-i18n');
        if (translations[key]) {
          element.textContent = translations[key];
        }
      });
      document.querySelectorAll('[data-i18n-placeholder]').forEach(element => {
        const key = element.getAttribute('data-i18n-placeholder');
        if (translations[key]) {
          element.setAttribute('placeholder', translations[key]);
        }
      });
    }
  
    await loadTranslations();
  
    // Przełączanie zakładek
    function switchTab(tab) {
      Object.values(tabs).forEach(t => t.classList.add('hidden'));
      Object.values(tabButtons).forEach(b => b.classList.remove('active'));
      tabs[tab].classList.remove('hidden');
      tabButtons[tab].classList.add('active');
    }
  
    tabButtons.downloader.addEventListener('click', () => switchTab('downloader'));
    tabButtons.archive.addEventListener('click', () => switchTab('archive'));
    tabButtons.backup.addEventListener('click', () => switchTab('backup'));
    tabButtons.stats.addEventListener('click', () => switchTab('stats'));
    tabButtons.settings.addEventListener('click', () => switchTab('settings'));
  
    // Logowanie do konsoli
    function log(message) {
      consoleEl.innerHTML += `${message}<br>`;
      consoleEl.scrollTop = consoleEl.scrollHeight;
    }
  
    window.ipcRenderer.on('log', (event, message) => log(message));
  
    // Resetowanie postępu
    function resetProgress() {
      const overallProgress = document.getElementById('overall-progress');
      const overallInfo = document.getElementById('overall-info');
      if (overallProgress && overallInfo) {
        overallProgress.querySelector('.progress-fill').style.width = '0%';
        overallInfo.textContent = translations.overall_progress
          ? translations.overall_progress.replace('0%', '0%')
          : 'Postęp ogólny: 0%';
      }
      ['assets', 'libs', 'versions'].forEach(type => {
        const section = document.getElementById(`${type}-section`);
        const progressBar = document.getElementById(`${type}-progress`);
        const infoEl = document.getElementById(`${type}-info`);
        const filesEl = document.getElementById(`${type}-files`);
        if (section) section.classList.add('hidden');
        if (progressBar && infoEl) {
          progressBar.querySelector('.progress-fill').style.width = '0%';
          const key = `${type}_progress`;
          infoEl.textContent = translations[key]
            ? translations[key]
                .replace('0/0 MB', '0/0 MB')
                .replace('0/0 plików', '0/0 plików')
                .replace('0 MB/s', '0 MB/s')
            : `${type.charAt(0).toUpperCase() + type.slice(1)}: 0/0 MB, 0/0 plików, 0 MB/s`;
          if (filesEl) filesEl.innerHTML = '';
        }
      });
    }
  
    // Aktualizacja ustawień
    async function updateSettings(updates) {
      settings = { ...settings, ...updates };
      if (updates.backup) {
        settings.backup = { ...settings.backup, ...updates.backup };
      }
      await window.ipcRenderer.send('update-settings', updates);
      if (updates.theme) {
        document.body.className = updates.theme;
      }
      if (updates.language) {
        await loadTranslations();
      }
      console.log('Zaktualizowano ustawienia:', JSON.stringify(settings, null, 2));
    }
  
    // Inicjalizacja ustawień w UI
    document.getElementById('menu-visible').checked = settings.menuVisible;
    document.getElementById('dev-tools').checked = settings.devToolsEnabled;
    document.getElementById('theme').value = settings.theme;
    document.getElementById('language').value = settings.language;
    document.getElementById('download-path').value = settings.downloadPath;
    document.getElementById('speed-limit').value = settings.speedLimit;
    document.getElementById('download-mode').value = settings.downloadMode;
    document.getElementById('animations').checked = settings.animations;
    document.getElementById('auto-refresh').checked = settings.autoRefresh;
    document.getElementById('analysis-mode').checked = settings.analysisMode;
    document.getElementById('compress-zip').checked = settings.backup.compressZip;
    document.getElementById('include-logs').checked = settings.backup.includeLogs;
    document.getElementById('overwrite-restore').checked = settings.backup.overwriteOnRestore;
    document.body.className = settings.theme;
  
    // Obsługa zmian ustawień
    document.getElementById('menu-visible').addEventListener('change', e => updateSettings({ menuVisible: e.target.checked }));
    document.getElementById('dev-tools').addEventListener('change', e => updateSettings({ devToolsEnabled: e.target.checked }));
    document.getElementById('theme').addEventListener('change', e => updateSettings({ theme: e.target.value }));
    document.getElementById('language').addEventListener('change', e => updateSettings({ language: e.target.value }));
    document.getElementById('download-path').addEventListener('change', e => {
      const newPath = e.target.value.replace(/\\/g, '/'); // Zamieniamy \ na / dla spójności
      console.log('Nowa ścieżka pobierania:', newPath);
      updateSettings({ downloadPath: newPath });
    });
    document.getElementById('speed-limit').addEventListener('change', e => {
        const speedLimitValue = e.target.value.trim() === '' ? '0' : e.target.value; // Domyślnie 0, jeśli puste
        updateSettings({ speedLimit: speedLimitValue });
      });
    document.getElementById('download-mode').addEventListener('change', e => updateSettings({ downloadMode: e.target.value }));
    document.getElementById('animations').addEventListener('change', e => updateSettings({ animations: e.target.checked }));
    document.getElementById('auto-refresh').addEventListener('change', e => updateSettings({ autoRefresh: e.target.checked }));
    document.getElementById('analysis-mode').addEventListener('change', e => {
      settings.analysisMode = e.target.checked;
      console.log('Tryb analizy:', settings.analysisMode);
    });
    document.getElementById('compress-zip').addEventListener('change', e =>
      updateSettings({ backup: { ...settings.backup, compressZip: e.target.checked } })
    );
    document.getElementById('include-logs').addEventListener('change', e =>
      updateSettings({ backup: { ...settings.backup, includeLogs: e.target.checked } })
    );
    document.getElementById('overwrite-restore').addEventListener('change', e =>
      updateSettings({ backup: { ...settings.backup, overwriteOnRestore: e.target.checked } })
    );
    document.getElementById('clear-logs').addEventListener('click', () => window.ipcRenderer.send('clear-logs'));
  
    // Pobieranie wersji Minecrafta
    async function fetchVersions() {
      try {
        const response = await fetch('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json');
        const data = await response.json();
        const versionsList = document.getElementById('versions-list');
        versionsList.innerHTML = '';
        data.versions.forEach(version => {
          const option = document.createElement('option');
          option.value = version.id;
          option.textContent = `${version.id} (${version.type})`;
          versionsList.appendChild(option);
        });
        console.log('Wczytano wersje Minecrafta');
  
        // Obsługa przycisku "Zaznacz wszystko"
        const selectAllButton = document.getElementById('select-all-versions');
        let allSelected = false;
        selectAllButton.addEventListener('click', () => {
          allSelected = !allSelected;
          Array.from(versionsList.options).forEach(option => {
            option.selected = allSelected;
          });
          selectAllButton.querySelector('span').textContent = allSelected
            ? translations.deselect_all_versions || 'Odznacz wszystko'
            : translations.select_all_versions || 'Zaznacz wszystko';
        });
      } catch (err) {
        console.error('Błąd pobierania wersji:', err);
        log(`Błąd pobierania wersji: ${err.message}`);
      }
    }
  
    fetchVersions();
  
    // Obsługa pobierania
    async function startDownload(type, selectedVersions = []) {
      if (isDownloading) {
        log('Już pobieram, spokojnie!');
        return;
      }
      isDownloading = true;
      controller = new AbortController();
      const signal = controller.signal;
      stopButton.disabled = false;
      progressPanel.classList.remove('hidden');
      resetProgress();
      console.log(`Rozpoczynam ${type}...`);
      log(`Rozpoczynam ${type}...`);
      try {
        await window.ipcRenderer.invoke(type, { signal, versions: selectedVersions });
        log(`Pomyślnie zakończono ${type}`);
      } catch (err) {
        console.error(`Błąd podczas ${type}:`, err);
        log(`Błąd podczas ${type}: ${err.message}`);
        // Pokazujemy błąd w modalu
        const modal = document.getElementById('modal');
        const modalText = document.getElementById('modal-text');
        modalText.textContent = `Błąd podczas ${type}: ${err.message}`;
        modal.classList.remove('hidden');
      } finally {
        isDownloading = false;
        stopButton.disabled = true;
        controller = null;
      }
    }
  
    document.getElementById('check-assets').addEventListener('click', () => {
      const selectedVersions = Array.from(document.querySelectorAll('#versions-list option:checked')).map(option => option.value);
      startDownload('check-assets', selectedVersions);
    });
    document.getElementById('check-libraries').addEventListener('click', () => {
      startDownload('check-libraries');
    });
    document.getElementById('check-manifest').addEventListener('click', () => {
      startDownload('check-manifest');
    });
    document.getElementById('check-versions').addEventListener('click', () => {
      startDownload('check-versions');
    });
    document.getElementById('check-all').addEventListener('click', () => {
      const selectedVersions = Array.from(document.querySelectorAll('#versions-list option:checked')).map(option => option.value);
      startDownload('check-all', selectedVersions);
    });
    document.getElementById('stop').addEventListener('click', () => {
      if (controller) {
        controller.abort();
        window.ipcRenderer.send('stop');
        isDownloading = false;
        stopButton.disabled = true;
        log('Zatrzymano pobieranie');
      } else {
        log('Nic do zatrzymania, ziom!');
      }
    });
  
    // Aktualizacja postępu
    window.ipcRenderer.on('progress', (event, data) => {
      console.log('Postęp:', data);
      const { type, percent, mb, totalMb, files, totalFiles, speed, overall, fileProgress, subTaskProgress } = data;
  
      const overallProgress = document.getElementById('overall-progress');
      const overallInfo = document.getElementById('overall-info');
      if (overallProgress && overallInfo) {
        overallProgress.querySelector('.progress-fill').style.width = `${overall}%`;
        overallInfo.textContent = translations.overall_progress
          ? translations.overall_progress.replace('0%', `${overall.toFixed(1)}%`)
          : `Postęp ogólny: ${overall.toFixed(1)}%`;
      }
  
      const section = document.getElementById(`${type}-section`);
      const progressBar = document.getElementById(`${type}-progress`);
      const infoEl = document.getElementById(`${type}-info`);
      const filesEl = document.getElementById(`${type}-files`);
      if (section && progressBar && infoEl) {
        section.classList.remove('hidden');
        progressBar.querySelector('.progress-fill').style.width = `${percent}%`;
        const key = `${type}_progress`;
        infoEl.textContent = translations[key]
          ? translations[key]
              .replace('0/0 MB', `${mb.toFixed(1)}/${totalMb.toFixed(1)} MB`)
              .replace('0/0 plików', `${files}/${totalFiles} plików`)
              .replace('0 MB/s', `${speed.toFixed(2)} MB/s`)
          : `${type.charAt(0).toUpperCase() + type.slice(1)}: ${mb.toFixed(1)}/${totalMb.toFixed(1)} MB, ${files}/${totalFiles} plików, ${speed.toFixed(2)} MB/s`;
      }
  
      if (fileProgress && filesEl) {
        let fileDiv = filesEl.querySelector(`[data-file="${fileProgress.fileName}"]`);
        if (!fileDiv) {
          fileDiv = document.createElement('div');
          fileDiv.className = 'sub-progress';
          fileDiv.setAttribute('data-file', fileProgress.fileName);
          fileDiv.innerHTML = `
            <p class="progress-info">${fileProgress.fileName}</p>
            <div class="progress-bar"><div class="progress-fill"></div></div>
            <p class="progress-info">${fileProgress.downloadedMb.toFixed(1)}/${fileProgress.totalMb.toFixed(1)} MB, ${fileProgress.speed.toFixed(2)} MB/s</p>
          `;
          filesEl.appendChild(fileDiv);
        }
        const fill = fileDiv.querySelector('.progress-fill');
        const info = fileDiv.querySelectorAll('.progress-info')[1];
        fill.style.width = `${fileProgress.percent}%`;
        info.textContent = `${fileProgress.downloadedMb.toFixed(1)}/${fileProgress.totalMb.toFixed(1)} MB, ${fileProgress.speed.toFixed(2)} MB/s`;
  
        if (subTaskProgress) {
          let subDiv = fileDiv.querySelector('.sub-sub-progress');
          if (!subDiv) {
            subDiv = document.createElement('div');
            subDiv.className = 'sub-sub-progress';
            subDiv.innerHTML = `
              <p class="progress-info">${subTaskProgress.subTask}</p>
              <div class="progress-bar"><div class="progress-fill"></div></div>
            `;
            fileDiv.appendChild(subDiv);
          }
          const subFill = subDiv.querySelector('.progress-fill');
          subFill.style.width = `${subTaskProgress.percent}%`;
        }
      }
    });
  
    window.ipcRenderer.on('assets-summary', (event, summary) => {
      console.log('Podsumowanie assetsów:', summary);
      const assetsSummary = document.getElementById('assets-summary');
      if (assetsSummary) {
        assetsSummary.textContent = translations.assets_summary
          ? translations.assets_summary
              .replace('0 unikalnych assetów', `${summary.totalFiles} unikalnych assetów`)
              .replace('0 MB', `${summary.totalMb} MB`)
          : `Znaleziono ${summary.totalFiles} unikalnych assetów, łączny rozmiar: ${summary.totalMb} MB`;
      }
    });
  
    // Wyświetlanie modalu
    window.ipcRenderer.on('modal', (event, message) => {
      console.log('Modal:', message);
      const modal = document.getElementById('modal');
      const modalText = document.getElementById('modal-text');
      modalText.textContent = message;
      modal.classList.remove('hidden');
      document.getElementById('modal-close').addEventListener('click', () => {
        modal.classList.add('hidden');
      });
    });
  
    // Obsługa archiwum
    let archiveData = [];
    async function fetchArchive() {
      console.log('Pobieram archiwum...');
      await window.ipcRenderer.send('get-archive');
    }
  
    window.ipcRenderer.on('archive', (event, { data, size }) => {
      console.log('Archiwum:', data);
      archiveData = data;
      const archiveList = document.getElementById('archive-list');
      const archiveSize = document.getElementById('archive-size');
      const archiveEmpty = document.getElementById('archive-empty');
      archiveList.innerHTML = '';
      archiveSize.textContent = translations.archive_size
        ? translations.archive_size.replace('0 MB', `${size.toFixed(1)} MB`)
        : `Rozmiar archiwum: ${size.toFixed(1)} MB`;
  
      if (data.length === 0) {
        archiveEmpty.classList.remove('hidden');
        return;
      }
      archiveEmpty.classList.add('hidden');
  
      const filteredData = filterArchive();
      filteredData.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${item.type}</td>
          <td>${item.name}</td>
          <td class="status-${item.status.toLowerCase().replace(' ', '-')}" data-i18n="status_${item.status
            .toLowerCase()
            .replace(' ', '_')}">${item.status}</td>
          <td>${item.size ? (item.size / (1024 * 1024)).toFixed(1) + ' MB' : '-'}</td>
          <td>
            <button class="action download-item" data-type="${item.type}" data-name="${item.name}" ${
              item.status === 'Posiadane' ? 'disabled' : ''
            }><i class="fas fa-download"></i></button>
            <button class="action preview-item" data-type="${item.type}" data-name="${item.name}" data-hash="${
              item.hash || ''
            }" ${!item.hash ? 'disabled' : ''}><i class="fas fa-eye"></i></button>
          </td>
        `;
        archiveList.appendChild(row);
      });
  
      applyTranslations();
      document.querySelectorAll('.download-item').forEach(button => {
        button.addEventListener('click', async () => {
          const type = button.getAttribute('data-type');
          const name = button.getAttribute('data-name');
          if (isDownloading) {
            log('Już pobieram, spokojnie!');
            return;
          }
          isDownloading = true;
          controller = new AbortController();
          const signal = controller.signal;
          try {
            await window.ipcRenderer.invoke('download-item', { signal, type, name });
            log(`Pobrano ${type}: ${name}`);
          } catch (err) {
            console.error(`Błąd podczas pobierania ${type}/${name}:`, err);
            log(`Błąd podczas pobierania ${type}/${name}: ${err.message}`);
          } finally {
            isDownloading = false;
            controller = null;
          }
          if (settings.autoRefresh) fetchArchive();
        });
      });
  
      document.querySelectorAll('.preview-item').forEach(button => {
        button.addEventListener('click', () => {
          const type = button.getAttribute('data-type');
          const name = button.getAttribute('data-name');
          const hash = button.getAttribute('data-hash');
          showPreview(type, name, hash);
        });
      });
    });
  
    // Filtrowanie archiwum
    function filterArchive() {
      const typeFilter = document.getElementById('type-filter').value;
      const nameFilter = document.getElementById('name-filter').value.toLowerCase();
      const hashFilter = document.getElementById('hash-filter').value.toLowerCase();
      const sizeFilter = document.getElementById('size-filter').value;
      const versionFilter = document.getElementById('version-filter').value.toLowerCase();
  
      return archiveData.filter(item => {
        if (typeFilter !== 'all' && item.type !== typeFilter) return false;
        if (nameFilter && !item.name.toLowerCase().includes(nameFilter)) return false;
        if (hashFilter && (!item.hash || !item.hash.toLowerCase().includes(hashFilter))) return false;
        if (versionFilter && item.version && !item.version.toLowerCase().includes(versionFilter)) return false;
        if (sizeFilter) {
          const sizeMb = item.size ? item.size / (1024 * 1024) : 0;
          if (sizeFilter.startsWith('>')) {
            const value = parseFloat(sizeFilter.slice(1));
            if (sizeMb <= value) return false;
          } else if (sizeFilter.startsWith('<')) {
            const value = parseFloat(sizeFilter.slice(1));
            if (sizeMb >= value) return false;
          } else {
            const value = parseFloat(sizeFilter);
            if (sizeMb !== value) return false;
          }
        }
        return true;
      });
    }
  
    document.getElementById('type-filter').addEventListener('change', () => fetchArchive());
    document.getElementById('name-filter').addEventListener('input', () => fetchArchive());
    document.getElementById('hash-filter').addEventListener('input', () => fetchArchive());
    document.getElementById('size-filter').addEventListener('input', () => fetchArchive());
    document.getElementById('version-filter').addEventListener('input', () => fetchArchive());
    document.getElementById('refresh-archive').addEventListener('click', () => fetchArchive());
  
    fetchArchive();
  
    // Sortowanie archiwum
    document.querySelectorAll('#archive th[data-sort]').forEach(header => {
      header.addEventListener('click', () => {
        const key = header.getAttribute('data-sort');
        archiveData.sort((a, b) => {
          if (key === 'size') {
            const aSize = a.size || 0;
            const bSize = b.size || 0;
            return aSize - bSize;
          }
          return a[key].localeCompare(b[key]);
        });
        fetchArchive();
      });
    });
  
    async function showPreview(type, name, hash) {
      console.log(`Podgląd: ${type}/${name}, hash: ${hash}`);
      const modal = document.getElementById('preview-modal');
      const title = document.getElementById('preview-title');
      const info = document.getElementById('preview-info');
      const image = document.getElementById('preview-image');
      const audio = document.getElementById('preview-audio');
  
      title.textContent = name;
      info.textContent = `Typ: ${type}, Hash: ${hash}`;
      image.classList.add('hidden');
      audio.classList.add('hidden');
  
      if (name.match(/\.(png|jpg|jpeg|gif)$/i)) {
        const url = `https://resources.download.minecraft.net/${hash.slice(0, 2)}/${hash}`;
        image.src = url;
        image.classList.remove('hidden');
      } else if (name.match(/\.(ogg|mp3|wav)$/i)) {
        const url = `https://resources.download.minecraft.net/${hash.slice(0, 2)}/${hash}`;
        audio.src = url;
        audio.classList.remove('hidden');
      } else {
        info.textContent += ' (Brak podglądu dla tego typu pliku)';
      }
  
      modal.classList.remove('hidden');
      document.getElementById('preview-close').addEventListener('click', () => {
        modal.classList.add('hidden');
        audio.pause();
      });
    }
  
    // Obsługa kopii zapasowych
    document.getElementById('export-backup').addEventListener('click', async () => {
      if (isDownloading) return;
      isDownloading = true;
      controller = new AbortController();
      stopButton.disabled = false;
      backupProgressPanel.classList.remove('hidden');
      console.log('Eksportuję do ZIP...');
      log('Eksportuję do ZIP...');
      await window.ipcRenderer.send('export-to-zip', controller.signal);
      isDownloading = false;
      stopButton.disabled = true;
    });
  
    document.getElementById('import-backup').addEventListener('click', async () => {
      if (isDownloading) return;
      isDownloading = true;
      controller = new AbortController();
      stopButton.disabled = false;
      backupProgressPanel.classList.remove('hidden');
      console.log('Importuję z ZIP...');
      log('Importuję z ZIP...');
      await window.ipcRenderer.send('import-from-zip', controller.signal);
      isDownloading = false;
      stopButton.disabled = true;
    });
  
    window.ipcRenderer.on('backup-progress', (event, data) => {
      console.log('Postęp backupu:', data);
      const backupProgress = document.getElementById('backup-progress');
      const backupInfo = document.getElementById('backup-info');
      if (backupProgress && backupInfo) {
        backupProgress.querySelector('.progress-fill').style.width = `${data.percent}%`;
        backupInfo.textContent = translations.backup_progress
          ? translations.backup_progress
              .replace('0 MB / 0 MB', `${data.processedMb.toFixed(1)} / ${data.totalMb.toFixed(1)} MB`)
              .replace('0 s', `${data.time.toFixed(1)} s`)
          : `Postęp: ${data.processedMb.toFixed(1)} / ${data.totalMb.toFixed(1)} MB, czas: ${data.time.toFixed(1)} s`;
      }
    });
  
    // Statystyki
    async function updateStats() {
      try {
        const stats = await window.ipcRenderer.invoke('get-stats');
        console.log('Statystyki:', JSON.stringify(stats, null, 2));
  
        // Domyślne wartości, jeśli coś jest undefined
        const downloadedMb = stats?.downloadedMb ?? 0;
        const totalAssets = stats?.totalAssets ?? 0;
        const totalLibraries = stats?.totalLibraries ?? 0;
        const totalVersions = stats?.totalVersions ?? 0;
        const totalTime = stats?.totalTime ?? 0;
  
        document.getElementById('stats-downloaded-mb').textContent = `${downloadedMb.toFixed(1)} MB`;
        document.getElementById('stats-total-assets').textContent = totalAssets;
        document.getElementById('stats-total-libraries').textContent = totalLibraries;
        document.getElementById('stats-total-versions').textContent = totalVersions;
        document.getElementById('stats-total-time').textContent = `${totalTime.toFixed(1)} s`;
      } catch (err) {
        console.error('Błąd pobierania statystyk:', err);
        log(`Błąd pobierania statystyk: ${err.message}`);
      }
    }
  
    updateStats();
  });