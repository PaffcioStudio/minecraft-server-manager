const { app, BrowserWindow, ipcMain, Menu } = require('electron');
const path = require('path');
const fs = require('fs-extra');
const axios = require('axios');
const winston = require('winston');

// Konfiguracja logowania
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ timestamp, level, message }) => `${timestamp} [${level.toUpperCase()}]: ${message}`)
  ),
  transports: [
    new winston.transports.File({ filename: path.join(app.getPath('userData'), 'logs/app.log') }),
    new winston.transports.Console()
  ]
});

let mainWindow;
let config = {
  menuVisible: true,
  devToolsEnabled: false,
  theme: 'dark',
  animations: true,
  speedLimit: '0',
  autoRefresh: false,
  downloadPath: '',
  downloadMode: 'missing',
  analysisMode: false,
  language: 'pl',
  backup: {
    compressZip: true,
    includeLogs: false,
    overwriteOnRestore: true
  }
};
const configPath = path.join(app.getPath('userData'), 'config.json');

// Wczytywanie konfiguracji
function loadConfig() {
  try {
    if (fs.existsSync(configPath)) {
      config = fs.readJsonSync(configPath);
      logger.info('Wczytano konfigurację z pliku');
    } else {
      fs.writeJsonSync(configPath, config, { spaces: 2 });
      logger.info('Utworzono domyślną konfigurację');
    }
  } catch (err) {
    logger.error(`Błąd wczytywania konfiguracji: ${err.message}`);
  }
}

// Zapisywanie konfiguracji
function saveConfig() {
  try {
    fs.writeJsonSync(configPath, config, { spaces: 2 });
    logger.info('Zapisano konfigurację');
  } catch (err) {
    logger.error(`Błąd zapisywania konfiguracji: ${err.message}`);
  }
}

// Tworzenie okna
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 900,
    height: 600,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      enableRemoteModule: false,
      nodeIntegration: false
    },
    frame: true,
    backgroundColor: '#1e1e1e'
  });

  mainWindow.loadFile('index.html');
  updateMenu();
  if (config.devToolsEnabled) mainWindow.webContents.openDevTools();
  mainWindow.on('closed', () => (mainWindow = null));
}

// Aktualizacja menu Electrona
function updateMenu() {
  const menuTemplate = config.menuVisible
    ? [
        {
          label: 'Plik',
          submenu: [
            { label: 'Zamknij', role: 'quit' },
            { label: 'Minimalizuj', role: 'minimize' }
          ]
        },
        {
          label: 'Pomoc',
          submenu: [
            { label: 'O aplikacji', click: () => mainWindow.webContents.send('modal', 'Pobieracz Minecraft v1.0') }
          ]
        }
      ]
    : [];
  const menu = Menu.buildFromTemplate(menuTemplate);
  Menu.setApplicationMenu(menu);
}

// Inicjalizacja aplikacji
app.whenReady().then(() => {
  loadConfig();
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// Obsługa ustawień
ipcMain.handle('get-settings', async () => {
  logger.info('Żądanie ustawień');
  return config;
});

ipcMain.on('update-settings', (event, newSettings) => {
  logger.info(`Otrzymano update-settings: ${JSON.stringify(newSettings)}`);
  config = { ...config, ...newSettings };
  saveConfig();
  if ('menuVisible' in newSettings) updateMenu();
  if ('devToolsEnabled' in newSettings) {
    newSettings.devToolsEnabled ? mainWindow.webContents.openDevTools() : mainWindow.webContents.closeDevTools();
  }
});

// Obsługa tłumaczeń
ipcMain.handle('get-translations', async (event, lang) => {
  logger.info(`Żądanie tłumaczeń dla języka: ${lang}`);
  try {
    const langPath = path.join(__dirname, 'assets', 'lang', `${lang}.json`);
    if (await fs.pathExists(langPath)) {
      const Translations = await fs.readJson(langPath);
      logger.info(`Wczytano tłumaczenia dla ${lang}`);
      return Translations; // Poprawiono literówkę
    } else {
      logger.error(`Plik tłumaczeń ${lang}.json nie istnieje`);
      throw new Error(`Plik tłumaczeń ${lang}.json nie istnieje`);
    }
  } catch (err) {
    logger.error(`Błąd wczytywania tłumaczeń: ${err.message}`);
    throw err;
  }
});

// Obsługa statystyk
ipcMain.handle('get-stats', async () => {
  logger.info('Żądanie statystyk');
  try {
    const stats = {
      downloadedMb: 0,
      totalAssets: 0,
      totalLibraries: 0,
      totalVersions: 0,
      totalDownloadTime: 0
    };
    logger.info('Zwrócono statystyki');
    return stats;
  } catch (err) {
    logger.error(`Błąd wczytywania statystyk: ${err.message}`);
    throw err;
  }
});

// Funkcja do ustawiania dynamicznego baseDir i tworzenia folderów
async function setupDownloadDirectories() {
  const baseDir = config.downloadPath && config.downloadPath.trim() !== ''
    ? config.downloadPath
    : path.join(app.getPath('userData'), 'minecraft'); // Domyślna ścieżka, jeśli nie ustawiono

  logger.info(`Ustawiam ścieżkę pobierania: ${baseDir}`);

  const dirs = {
    assets: path.join(baseDir, 'assets'),
    libraries: path.join(baseDir, 'libraries'),
    versions: path.join(baseDir, 'versions')
  };

  // Tworzenie folderów, jeśli nie istnieją
  try {
    await fs.ensureDir(baseDir); // Tworzy główny folder
    logger.info(`Utworzono główny folder: ${baseDir}`);
    for (const [type, dir] of Object.entries(dirs)) {
      await fs.ensureDir(dir);
      logger.info(`Utworzono folder ${type}: ${dir}`);
    }
  } catch (err) {
    logger.error(`Błąd podczas tworzenia folderów: ${err.message}`);
    throw new Error(`Nie udało się utworzyć folderów: ${err.message}`);
  }

  return { baseDir, dirs };
}

const manifestUrl = 'https://launchermeta.mojang.com/mc/game/version_manifest.json';
let versionsManifest = null;
let totalFiles = 0;
let downloadedFiles = 0;
let totalMb = 0;
let downloadedMb = 0;

// Funkcja pobierania z postępem i limitem prędkości
async function fetchWithProgress(url, dest, signal, type, fileName, subTask = null) {
    const startTime = Date.now();
    const writer = fs.createWriteStream(dest);
    let downloadedBytes = 0;
    let totalBytes = 0;
  
    try {
      logger.info(`Pobieram plik: ${url}`);
      const response = await axios({
        url,
        method: 'GET',
        responseType: 'stream',
        signal
      });
  
      totalBytes = parseInt(response.headers['content-length'] || '0', 10);
      totalMb += totalBytes / (1024 * 1024);
      totalFiles++;
  
      // Parsowanie speedLimit z config (przekształcamy string na liczbę)
      const speedLimitMbPerSec = parseFloat(config.speedLimit); // MB/s
      const speedLimitBytesPerSec = speedLimitMbPerSec * 1024 * 1024; // Przeliczamy na bajty/s
      const chunkInterval = 100; // Aktualizujemy co 100ms
      const maxBytesPerInterval = speedLimitBytesPerSec * (chunkInterval / 1000); // Maksymalna liczba bajtów na interwał
  
      let buffer = Buffer.alloc(0); // Bufor do przechowywania danych
      let lastUpdate = Date.now();
  
      response.data.on('data', chunk => {
        downloadedBytes += chunk.length;
        downloadedMb += chunk.length / (1024 * 1024);
        buffer = Buffer.concat([buffer, chunk]); // Dodajemy dane do bufora
  
        const now = Date.now();
        const elapsed = now - lastUpdate;
  
        if (elapsed >= chunkInterval) {
          const speed = (downloadedBytes / (1024 * 1024)) / ((now - startTime) / 1000);
          const percent = totalBytes ? (downloadedBytes / totalBytes) * 100 : 0;
          const overall = totalMb ? (downloadedMb / totalMb) * 100 : 0;
  
          const fileProgress = {
            fileName,
            percent,
            downloadedMb: downloadedBytes / (1024 * 1024),
            totalMb: totalBytes / (1024 * 1024),
            speed
          };
          const subTaskProgress = subTask ? { subTask, percent: percent * 0.5 } : null;
  
          mainWindow.webContents.send('progress', {
            type,
            percent: (downloadedFiles / totalFiles) * 100,
            mb: downloadedMb,
            totalMb,
            files: downloadedFiles,
            totalFiles,
            speed,
            overall,
            fileProgress,
            subTaskProgress
          });
  
          // Throttling: zapisujemy tylko tyle danych, ile pozwala limit
          if (speedLimitBytesPerSec > 0) {
            const bytesToWrite = Math.min(buffer.length, maxBytesPerInterval);
            const chunkToWrite = buffer.slice(0, bytesToWrite);
            writer.write(chunkToWrite);
            buffer = buffer.slice(bytesToWrite); // Usuwamy zapisane dane z bufora
          } else {
            // Brak limitu - zapisujemy wszystko od razu
            writer.write(buffer);
            buffer = Buffer.alloc(0);
          }
  
          lastUpdate = now;
        }
      });
  
      response.data.on('end', () => {
        // Zapisujemy resztę bufora po zakończeniu strumienia
        if (buffer.length > 0) {
          writer.write(buffer);
        }
        writer.end();
      });
  
      await new Promise((resolve, reject) => {
        writer.on('finish', () => {
          downloadedFiles++;
          mainWindow.webContents.send('progress', {
            type,
            percent: (downloadedFiles / totalFiles) * 100,
            mb: downloadedMb,
            totalMb,
            files: downloadedFiles,
            totalFiles,
            speed: 0,
            overall: totalMb ? (downloadedMb / totalMb) * 100 : 0,
            fileProgress: { fileName, percent: 100, downloadedMb: totalBytes / (1024 * 1024), totalMb: totalBytes / (1024 * 1024), speed: 0 },
            subTaskProgress: subTask ? { subTask, percent: 100 } : null
          });
          resolve();
        });
        writer.on('error', err => reject(new Error(`Błąd zapisu pliku ${fileName}: ${err.message}`)));
        signal?.addEventListener('abort', () => reject(new Error('Pobieranie anulowane')));
      });
    } catch (err) {
      logger.error(`Nie udało się pobrać/zapisać pliku ${url}: ${err.message}`);
      throw err;
    }
  }

// Funkcja indeksowania unikalnych assetów
async function checkAssets({ signal, versions }) {
  mainWindow.webContents.send('log', 'Sprawdzam assetsy...');
  
  // Ustawiamy dynamiczne ścieżki
  let baseDir, dirs;
  try {
    const setupResult = await setupDownloadDirectories();
    baseDir = setupResult.baseDir;
    dirs = setupResult.dirs;
  } catch (err) {
    mainWindow.webContents.send('modal', `Błąd podczas ustawiania ścieżek: ${err.message}`);
    throw err;
  }

  const assetsDir = dirs.assets;
  const indexesDir = path.join(assetsDir, 'indexes');
  const objectsDir = path.join(assetsDir, 'objects');

  // Tworzenie folderów indexes i objects, jeśli nie istnieją
  try {
    await fs.ensureDir(indexesDir);
    await fs.ensureDir(objectsDir);
    logger.info(`Utworzono folder indexes: ${indexesDir}`);
    logger.info(`Utworzono folder objects: ${objectsDir}`);
  } catch (err) {
    logger.error(`Błąd podczas tworzenia folderów indexes/objects: ${err.message}`);
    mainWindow.webContents.send('modal', `Błąd podczas tworzenia folderów indexes/objects: ${err.message}`);
    throw err;
  }

  try {
    if (signal?.aborted) throw new Error('Pobieranie anulowane');

    // Krok 1: Pobierz manifest wersji, jeśli jeszcze nie mamy
    if (!versionsManifest) {
      logger.info('Pobieram manifest wersji...');
      const { data } = await axios.get(manifestUrl, { signal });
      versionsManifest = data;
      fs.writeJsonSync(path.join(baseDir, 'version_manifest.json'), data);
      logger.info('Pobrano manifest wersji');
    }

    // Krok 2: Znajdź wersję 1.20 (lub inną, jeśli wybrano)
    let targetVersion = '1.20'; // Domyślnie 1.20, ale możemy to zmienić
    if (versions && versions.length > 0) {
      targetVersion = versions[0]; // Bierzemy pierwszą wybraną wersję
    }
    const versionData = versionsManifest.versions.find(v => v.id === targetVersion);
    if (!versionData) {
      throw new Error(`Wersja ${targetVersion} nie znaleziona w manifescie`);
    }
    logger.info(`Znaleziono wersję: ${targetVersion}`);

    // Krok 3: Pobierz szczegóły wersji (zawiera URL do indeksu assetów)
    logger.info(`Pobieram szczegóły wersji ${targetVersion}...`);
    const { data: versionDetails } = await axios.get(versionData.url, { signal });
    const assetsIndexUrl = versionDetails.assetIndex.url;
    const assetsIndexId = versionDetails.assetIndex.id;
    logger.info(`URL indeksu assetów: ${assetsIndexUrl}`);

    // Krok 4: Pobierz indeks assetów
    logger.info('Pobieram indeks assetów...');
    const { data: assetsIndex } = await axios.get(assetsIndexUrl, { signal });
    fs.writeJsonSync(path.join(indexesDir, `${assetsIndexId}.json`), assetsIndex);
    logger.info('Pobrano indeks assetów');

    const uniqueAssets = new Map();
    let totalSize = 0;

    for (const [key, { hash, size }] of Object.entries(assetsIndex.objects)) {
      if (!uniqueAssets.has(hash)) {
        uniqueAssets.set(hash, { key, hash, size });
        totalSize += size;
      }
    }

    totalFiles = uniqueAssets.size;
    totalMb = totalSize / (1024 * 1024);
    downloadedFiles = 0;
    downloadedMb = 0;

    mainWindow.webContents.send('assets-summary', {
      totalFiles: uniqueAssets.size,
      totalMb: totalMb.toFixed(1)
    });

    const batchSize = 5;
    const assetsArray = Array.from(uniqueAssets.values());
    for (let i = 0; i < assetsArray.length; i += batchSize) {
      if (signal?.aborted) throw new Error('Pobieranie anulowane');
      const batch = assetsArray.slice(i, i + batchSize);
      const promises = batch.map(async ({ key, hash, size }) => {
        const hashDir = hash.slice(0, 2);
        const hashPath = path.join(objectsDir, hashDir);
        await fs.ensureDir(hashPath); // Tworzymy podfolder dla hashu
        const filePath = path.join(hashPath, hash);
        if (!fs.existsSync(filePath) || fs.statSync(filePath).size !== size) {
          const url = `https://resources.download.minecraft.net/${hashDir}/${hash}`;
          await fetchWithProgress(url, filePath, signal, 'assets', key, 'pobieranie');
          await new Promise(resolve => setTimeout(resolve, 100));
          mainWindow.webContents.send('progress', {
            type: 'assets',
            fileProgress: { fileName: key, subTask: 'zapisywanie', percent: 100 }
          });
        } else {
          downloadedFiles++;
          downloadedMb += size / (1024 * 1024);
          mainWindow.webContents.send('progress', {
            type: 'assets',
            percent: (downloadedFiles / totalFiles) * 100,
            mb: downloadedMb,
            totalMb,
            files: downloadedFiles,
            totalFiles,
            speed: 0,
            overall: totalMb ? (downloadedMb / totalMb) * 100 : 0,
            fileProgress: { fileName: key, percent: 100, downloadedMb: size / (1024 * 1024), totalMb: size / (1024 * 1024), speed: 0 }
          });
        }
      });
      await Promise.allSettled(promises);
    }

    mainWindow.webContents.send('modal', 'Assetsy sprawdzone pomyślnie!');
    logger.info('Assetsy sprawdzone pomyślnie');
  } catch (err) {
    logger.error(`Błąd podczas pobierania assetsów: ${err.message}`);
    mainWindow.webContents.send('modal', `Błąd podczas pobierania assetsów: ${err.message}`);
    throw err;
  }
}

async function checkLibraries({ signal, versions }) {
  mainWindow.webContents.send('log', 'Sprawdzam biblioteki...');
  let dirs;
  try {
    const setupResult = await setupDownloadDirectories();
    dirs = setupResult.dirs;
  } catch (err) {
    mainWindow.webContents.send('modal', `Błąd podczas ustawiania ścieżek: ${err.message}`);
    throw err;
  }
  try {
    if (signal?.aborted) throw new Error('Pobieranie anulowane');
    // Placeholder - dodaj logikę pobierania bibliotek
    mainWindow.webContents.send('modal', 'Biblioteki sprawdzone pomyślnie!');
    logger.info('Biblioteki sprawdzone pomyślnie');
  } catch (err) {
    logger.error(`Błąd podczas pobierania bibliotek: ${err.message}`);
    mainWindow.webContents.send('modal', `Błąd podczas pobierania bibliotek: ${err.message}`);
    throw err;
  }
}

async function checkManifest({ signal, versions }) {
  mainWindow.webContents.send('log', 'Sprawdzam manifest...');
  let baseDir;
  try {
    const setupResult = await setupDownloadDirectories();
    baseDir = setupResult.baseDir;
  } catch (err) {
    mainWindow.webContents.send('modal', `Błąd podczas ustawiania ścieżek: ${err.message}`);
    throw err;
  }
  try {
    if (signal?.aborted) throw new Error('Pobieranie anulowane');
    const { data } = await axios.get(manifestUrl, { signal });
    versionsManifest = data;
    fs.writeJsonSync(path.join(baseDir, 'version_manifest.json'), data);
    mainWindow.webContents.send('modal', 'Manifest sprawdzony pomyślnie!');
    logger.info('Manifest sprawdzony pomyślnie');
  } catch (err) {
    logger.error(`Błąd podczas pobierania manifestu: ${err.message}`);
    mainWindow.webContents.send('modal', `Błąd podczas pobierania manifestu: ${err.message}`);
    throw err;
  }
}

async function checkVersions({ signal, versions }) {
  mainWindow.webContents.send('log', 'Sprawdzam wersje...');
  let dirs;
  try {
    const setupResult = await setupDownloadDirectories();
    dirs = setupResult.dirs;
  } catch (err) {
    mainWindow.webContents.send('modal', `Błąd podczas ustawiania ścieżek: ${err.message}`);
    throw err;
  }
  try {
    if (signal?.aborted) throw new Error('Pobieranie anulowane');
    // Placeholder - dodaj logikę pobierania wersji
    mainWindow.webContents.send('modal', 'Wersje sprawdzone pomyślnie!');
    logger.info('Wersje sprawdzone pomyślnie');
  } catch (err) {
    logger.error(`Błąd podczas pobierania wersji: ${err.message}`);
    mainWindow.webContents.send('modal', `Błąd podczas pobierania wersji: ${err.message}`);
    throw err;
  }
}

async function checkAll({ signal, versions }) {
  mainWindow.webContents.send('log', 'Sprawdzam wszystko...');
  let dirs;
  try {
    const setupResult = await setupDownloadDirectories();
    dirs = setupResult.dirs;
  } catch (err) {
    mainWindow.webContents.send('modal', `Błąd podczas ustawiania ścieżek: ${err.message}`);
    throw err;
  }
  try {
    totalFiles = 0;
    downloadedFiles = 0;
    totalMb = 0;
    downloadedMb = 0;
    await Promise.all([
      checkAssets({ signal, versions }),
      checkLibraries({ signal, versions }),
      checkManifest({ signal, versions }),
      checkVersions({ signal, versions })
    ]);
    mainWindow.webContents.send('modal', 'Wszystko sprawdzone pomyślnie!');
    logger.info('Wszystko sprawdzone pomyślnie');
  } catch (err) {
    logger.error(`Błąd podczas sprawdzania wszystkiego: ${err.message}`);
    mainWindow.webContents.send('modal', `Błąd podczas sprawdzania wszystkiego: ${err.message}`);
    throw err;
  }
}

async function downloadItem({ signal, type, name }) {
  mainWindow.webContents.send('log', `Pobieram ${type}: ${name}...`);
  let dirs;
  try {
    const setupResult = await setupDownloadDirectories();
    dirs = setupResult.dirs;
  } catch (err) {
    mainWindow.webContents.send('modal', `Błąd podczas ustawiania ścieżek: ${err.message}`);
    throw err;
  }
  try {
    if (signal?.aborted) throw new Error('Pobieranie anulowane');
    // Placeholder - dodaj logikę pobierania pojedynczego elementu
    mainWindow.webContents.send('modal', `Pobrano ${type}: ${name} pomyślnie!`);
    logger.info(`Pobrano ${type}: ${name} pomyślnie`);
  } catch (err) {
    logger.error(`Błąd podczas pobierania ${type}/${name}: ${err.message}`);
    mainWindow.webContents.send('modal', `Błąd podczas pobierania ${type}/${name}: ${err.message}`);
    throw err;
  }
}

async function getArchive() {
  logger.info('Pobieranie archiwum...');
  let baseDir, dirs;
  try {
    const setupResult = await setupDownloadDirectories();
    baseDir = setupResult.baseDir;
    dirs = setupResult.dirs;
  } catch (err) {
    logger.error(`Błąd podczas ustawiania ścieżek w getArchive: ${err.message}`);
    mainWindow.webContents.send('modal', `Błąd podczas ustawiania ścieżek: ${err.message}`);
    return; // Wychodzimy, jeśli nie udało się ustawić ścieżek
  }

  try {
    const data = [];
    let size = 0;

    // Skanowanie folderów assets, libraries, versions
    for (const [type, dir] of Object.entries(dirs)) {
      if (fs.existsSync(dir)) {
        const files = fs.readdirSync(dir, { recursive: true }); // Skanujemy rekurencyjnie
        for (const file of files) {
          const filePath = path.join(dir, file);
          const stats = fs.statSync(filePath);
          if (stats.isFile()) {
            data.push({
              type,
              name: path.relative(dir, filePath).replace(/\\/g, '/'), // Zmieniamy \ na /
              status: 'Posiadane',
              size: stats.size
            });
            size += stats.size;
          }
        }
      }
    }

    // Sprawdzanie version_manifest.json
    const manifestPath = path.join(baseDir, 'version_manifest.json');
    if (fs.existsSync(manifestPath)) {
      const stats = fs.statSync(manifestPath);
      data.push({ type: 'version', name: 'version_manifest.json', status: 'Posiadane', size: stats.size });
      size += stats.size;
    } else {
      data.push({ type: 'version', name: 'version_manifest.json', status: 'Brak' });
    }

    // Sprawdzanie indeksów assetów
    const indexesDir = path.join(dirs.assets, 'indexes');
    if (fs.existsSync(indexesDir)) {
      const indexFiles = fs.readdirSync(indexesDir);
      for (const file of indexFiles) {
        const filePath = path.join(indexesDir, file);
        const stats = fs.statSync(filePath);
        if (stats.isFile()) {
          data.push({
            type: 'asset',
            name: `assets/indexes/${file}`,
            status: 'Posiadane',
            size: stats.size
          });
          size += stats.size;
        }
      }
    }

    mainWindow.webContents.send('archive', { data, size: size / (1024 * 1024) });
    logger.info('Wysłano dane archiwum');
  } catch (err) {
    logger.error(`Błąd podczas pobierania archiwum: ${err.message}`);
    mainWindow.webContents.send('modal', `Błąd podczas pobierania archiwum: ${err.message}`);
  }
}

// Obsługa IPC z renderer.js
ipcMain.handle('check-assets', async (event, args) => {
  try {
    await checkAssets(args);
  } catch (err) {
    logger.error(`Błąd w check-assets: ${err.message}`);
    throw err;
  }
});
ipcMain.handle('check-libraries', async (event, args) => {
  try {
    await checkLibraries(args);
  } catch (err) {
    logger.error(`Błąd w check-libraries: ${err.message}`);
    throw err;
  }
});
ipcMain.handle('check-manifest', async (event, args) => {
  try {
    await checkManifest(args);
  } catch (err) {
    logger.error(`Błąd w check-manifest: ${err.message}`);
    throw err;
  }
});
ipcMain.handle('check-versions', async (event, args) => {
  try {
    await checkVersions(args);
  } catch (err) {
    logger.error(`Błąd w check-versions: ${err.message}`);
    throw err;
  }
});
ipcMain.handle('check-all', async (event, args) => {
  try {
    await checkAll(args);
  } catch (err) {
    logger.error(`Błąd w check-all: ${err.message}`);
    throw err;
  }
});
ipcMain.handle('download-item', async (event, args) => {
  try {
    await downloadItem(args);
  } catch (err) {
    logger.error(`Błąd w download-item: ${err.message}`);
    throw err;
  }
});
ipcMain.on('get-archive', () => {
  getArchive();
});
ipcMain.on('stop', () => {
  logger.info('Otrzymano sygnał zatrzymania');
  totalFiles = 0;
  downloadedFiles = 0;
  totalMb = 0;
  downloadedMb = 0;
  mainWindow.webContents.send('log', 'Zatrzymano pobieranie');
});