const { fetchManifest, fetchVersionManifest, downloadFile, logger } = require('./api');
const { downloadAssets, downloadLibraries, downloadVersions, downloadItem } = require('./downloader');
const fs = require('fs-extra');
const path = require('path');

async function checkAssets(ipcMain, signal) {
  logger.info('Sprawdzanie assetsów...');
  try {
    await downloadAssets((type, percent, mb, totalMb, files, totalFiles, speed) => {
      if (!ipcMain.isDestroyed()) {
        ipcMain.send('progress', { type, percent, mb, totalMb, files, totalFiles, speed, overall: 0 });
        ipcMain.send('log', `Postęp assetsów: ${percent.toFixed(2)}%`);
      }
    }, signal);
    if (!ipcMain.isDestroyed()) {
      ipcMain.send('modal', `Pobrano wszystkie assetsy`);
      ipcMain.send('log', 'Sprawdzanie assetsów zakończone pomyślnie');
    }
  } catch (e) {
    if (e.message.includes('Przerwano')) {
      logger.info('Sprawdzanie assetsów przerwane');
      if (!ipcMain.isDestroyed()) {
        ipcMain.send('modal', 'Pobieranie assetsów przerwane');
        ipcMain.send('log', 'Pobieranie assetsów przerwane');
      }
      return;
    }
    logger.error(`Błąd podczas sprawdzania assetsów: ${e.message}`);
    if (!ipcMain.isDestroyed()) {
      ipcMain.send('modal', `Błąd podczas pobierania assetsów: ${e.message}`);
      ipcMain.send('log', `Błąd assetsów: ${e.message}`);
    }
    throw e;
  }
}

async function checkLibraries(ipcMain, signal) {
  logger.info('Sprawdzanie bibliotek...');
  try {
    await downloadLibraries((type, percent, mb, totalMb, files, totalFiles, speed) => {
      if (!ipcMain.isDestroyed()) {
        ipcMain.send('progress', { type, percent, mb, totalMb, files, totalFiles, speed, overall: 0 });
        ipcMain.send('log', `Postęp bibliotek: ${percent.toFixed(2)}%`);
      }
    }, signal);
    if (!ipcMain.isDestroyed()) {
      ipcMain.send('modal', 'Pobrano wszystkie biblioteki');
      ipcMain.send('log', 'Sprawdzanie bibliotek zakończone pomyślnie');
    }
  } catch (e) {
    if (e.message.includes('Przerwano')) {
      logger.info('Sprawdzanie bibliotek przerwane');
      if (!ipcMain.isDestroyed()) {
        ipcMain.send('modal', 'Pobieranie bibliotek przerwane');
        ipcMain.send('log', 'Pobieranie bibliotek przerwane');
      }
      return;
    }
    logger.error(`Błąd podczas sprawdzania bibliotek: ${e.message}`);
    if (!ipcMain.isDestroyed()) {
      ipcMain.send('modal', `Błąd podczas pobierania bibliotek: ${e.message}`);
      ipcMain.send('log', `Błąd bibliotek: ${e.message}`);
    }
    throw e;
  }
}

async function checkManifest(ipcMain, signal) {
  logger.info('Sprawdzanie manifestu...');
  try {
    await fetchManifest(signal);
    if (!ipcMain.isDestroyed()) {
      ipcMain.send('modal', 'Pobrano manifest wersji');
      ipcMain.send('log', 'Sprawdzanie manifestu zakończone pomyślnie');
    }
  } catch (e) {
    if (e.message.includes('Przerwano')) {
      logger.info('Sprawdzanie manifestu przerwane');
      if (!ipcMain.isDestroyed()) {
        ipcMain.send('modal', 'Pobieranie manifestu przerwane');
        ipcMain.send('log', 'Pobieranie manifestu przerwane');
      }
      return;
    }
    logger.error(`Błąd podczas sprawdzania manifestu: ${e.message}`);
    if (!ipcMain.isDestroyed()) {
      ipcMain.send('modal', `Błąd podczas pobierania manifestu: ${e.message}`);
      ipcMain.send('log', `Błąd manifestu: ${e.message}`);
    }
    throw e;
  }
}

async function checkVersions(ipcMain, signal) {
  logger.info('Sprawdzanie wersji...');
  try {
    await downloadVersions((type, percent, mb, totalMb, files, totalFiles, speed) => {
      if (!ipcMain.isDestroyed()) {
        ipcMain.send('progress', { type, percent, mb, totalMb, files, totalFiles, speed, overall: 0 });
        ipcMain.send('log', `Postęp wersji: ${percent.toFixed(2)}%`);
      }
    }, signal);
    if (!ipcMain.isDestroyed()) {
      ipcMain.send('modal', 'Pobrano wszystkie wersje');
      ipcMain.send('log', 'Sprawdzanie wersji zakończone pomyślnie');
    }
  } catch (e) {
    if (e.message.includes('Przerwano')) {
      logger.info('Sprawdzanie wersji przerwane');
      if (!ipcMain.isDestroyed()) {
        ipcMain.send('modal', 'Pobieranie wersji przerwane');
        ipcMain.send('log', 'Pobieranie wersji przerwane');
      }
      return;
    }
    logger.error(`Błąd podczas sprawdzania wersji: ${e.message}`);
    if (!ipcMain.isDestroyed()) {
      ipcMain.send('modal', `Błąd podczas pobierania wersji: ${e.message}`);
      ipcMain.send('log', `Błąd wersji: ${e.message}`);
    }
    throw e;
  }
}

async function checkAll(ipcMain, signal) {
  logger.info('Sprawdzanie wszystkich zasobów...');
  try {
    await checkManifest(ipcMain, signal);
    if (!ipcMain.isDestroyed()) {
      ipcMain.send('progress', { type: 'overall', percent: 25, mb: 0, totalMb: 0, files: 0, totalFiles: 0, speed: 0, overall: 25 });
      ipcMain.send('log', 'Postęp ogólny: 25% (manifest)');
    }
    await checkVersions(ipcMain, signal);
    if (!ipcMain.isDestroyed()) {
      ipcMain.send('progress', { type: 'overall', percent: 50, mb: 0, totalMb: 0, files: 0, totalFiles: 0, speed: 0, overall: 50 });
      ipcMain.send('log', 'Postęp ogólny: 50% (wersje)');
    }
    await checkLibraries(ipcMain, signal);
    if (!ipcMain.isDestroyed()) {
      ipcMain.send('progress', { type: 'overall', percent: 75, mb: 0, totalMb: 0, files: 0, totalFiles: 0, speed: 0, overall: 75 });
      ipcMain.send('log', 'Postęp ogólny: 75% (biblioteki)');
    }
    await checkAssets(ipcMain, signal);
    if (!ipcMain.isDestroyed()) {
      ipcMain.send('progress', { type: 'overall', percent: 100, mb: 0, totalMb: 0, files: 0, totalFiles: 0, speed: 0, overall: 100 });
      ipcMain.send('modal', 'Pobrano wszystkie zasoby');
      ipcMain.send('log', 'Sprawdzanie wszystkich zasobów zakończone pomyślnie');
    }
  } catch (e) {
    if (e.message.includes('Przerwano')) {
      logger.info('Sprawdzanie wszystkich zasobów przerwane');
      if (!ipcMain.isDestroyed()) {
        ipcMain.send('modal', 'Pobieranie wszystkich zasobów przerwane');
        ipcMain.send('log', 'Pobieranie wszystkich zasobów przerwane');
      }
      return;
    }
    logger.error(`Błąd podczas sprawdzania wszystkich zasobów: ${e.message}`);
    if (!ipcMain.isDestroyed()) {
      ipcMain.send('modal', `Błąd podczas pobierania zasobów: ${e.message}`);
      ipcMain.send('log', `Błąd zasobów: ${e.message}`);
    }
    throw e;
  }
}

async function getArchive(ipcMain) {
  logger.info('Generowanie listy archiwum...');
  const archive = [];
  let totalSize = 0;

  try {
    const minecraftPath = path.join(__dirname, '../minecraft');
    await fs.ensureDir(minecraftPath);
    const manifestPath = path.join(minecraftPath, 'manifest.json');
    logger.info(`Sprawdzanie manifestu w: ${manifestPath}`);
    let manifest = { versions: [] };
    if (await fs.pathExists(manifestPath)) {
      manifest = await fs.readJson(manifestPath);
      logger.info(`Znaleziono manifest z ${manifest.versions.length} wersjami`);
    } else {
      logger.info('Brak manifest.json, folder minecraft pusty');
    }

    // Wersje
    const versionsPath = path.join(minecraftPath, 'versions');
    await fs.ensureDir(versionsPath);
    logger.info(`Skanowanie wersji w: ${versionsPath}`);
    for (const version of manifest.versions) {
      const versionPath = path.join(versionsPath, version.id, `${version.id}.jar`);
      if (await fs.pathExists(versionPath)) {
        const stats = await fs.stat(versionPath);
        totalSize += stats.size;
        logger.info(`Znaleziono wersję: ${version.id}, rozmiar: ${stats.size} bajtów`);
      }
      archive.push({
        type: 'version',
        name: version.id,
        status: await fs.pathExists(versionPath) ? 'Posiadane' : 'Brak'
      });
    }

    // Biblioteki
    const librariesPath = path.join(minecraftPath, 'libraries');
    await fs.ensureDir(librariesPath);
    logger.info(`Skanowanie bibliotek w: ${librariesPath}`);
    for (const version of manifest.versions) {
      const versionManifest = await fetchVersionManifest(version.id);
      for (const lib of versionManifest.libraries) {
        if (lib.downloads?.artifact) {
          const libPath = path.join(librariesPath, lib.downloads.artifact.path);
          if (await fs.pathExists(libPath)) {
            const stats = await fs.stat(libPath);
            totalSize += stats.size;
            logger.info(`Znaleziono bibliotekę: ${lib.downloads.artifact.path}, rozmiar: ${stats.size} bajtów`);
          }
          archive.push({
            type: 'library',
            name: lib.downloads.artifact.path,
            status: await fs.pathExists(libPath) ? 'Posiadane' : 'Brak'
          });
        }
      }
    }

    // Assets
    const assetsPath = path.join(minecraftPath, 'assets');
    const indexesPath = path.join(assetsPath, 'indexes');
    await fs.ensureDir(indexesPath);
    logger.info(`Skanowanie assetsów w: ${indexesPath}`);
    const assetIndexes = await fs.readdir(indexesPath).catch(() => []);
    for (const index of assetIndexes) {
      const assetIndexPath = path.join(indexesPath, index);
      logger.info(`Wczytywanie assetIndex: ${assetIndexPath}`);
      const assetIndexData = await fs.readJson(assetIndexPath).catch(() => ({ objects: {} }));
      logger.info(`Załadowano ${Object.keys(assetIndexData.objects).length} assetsów z ${index}`);
      for (const [key, asset] of Object.entries(assetIndexData.objects)) {
        const assetPath = path.join(assetsPath, 'objects', asset.hash.slice(0, 2), asset.hash);
        if (await fs.pathExists(assetPath)) {
          const stats = await fs.stat(assetPath);
          totalSize += stats.size;
          logger.info(`Znaleziono asset: ${asset.hash}, rozmiar: ${stats.size} bajtów`);
        }
        archive.push({
          type: 'asset',
          name: asset.hash,
          status: await fs.pathExists(assetPath) ? 'Posiadane' : 'Brak'
        });
      }
    }

    if (!ipcMain.isDestroyed()) {
      logger.info(`Wysyłanie listy archiwum: ${archive.length} elementów, rozmiar: ${totalSize / (1024 * 1024)} MB`);
      ipcMain.send('archive', { data: archive, size: totalSize / (1024 * 1024) });
      logger.info('Lista archiwum wygenerowana pomyślnie');
    }
  } catch (e) {
    logger.error(`Błąd podczas generowania archiwum: ${e.message}`);
    if (!ipcMain.isDestroyed()) {
      ipcMain.send('modal', `Błąd podczas generowania archiwum: ${e.message}`);
      ipcMain.send('log', `Błąd archiwum: ${e.message}`);
    }
  }
}

async function downloadItemHandler(ipcMain, type, name, signal) {
  logger.info(`Pobieranie elementu ${type}: ${name}...`);
  try {
    await downloadItem(type, name, (type, percent, mb, totalMb, files, totalFiles, speed) => {
      if (!ipcMain.isDestroyed()) {
        ipcMain.send('progress', { type, percent, mb, totalMb, files, totalFiles, speed, overall: 0 });
        ipcMain.send('log', `Postęp ${type}: ${percent.toFixed(2)}%`);
      }
    }, signal);
    if (!ipcMain.isDestroyed()) {
      ipcMain.send('modal', `Pobrano ${type}: ${name}`);
      ipcMain.send('log', `Pobieranie elementu ${type}: ${name} zakończone pomyślnie`);
    }
  } catch (e) {
    if (e.message.includes('Przerwano')) {
      logger.info(`Pobieranie elementu ${type}: ${name} przerwane`);
      if (!ipcMain.isDestroyed()) {
        ipcMain.send('modal', `Pobieranie ${type}: ${name} przerwane`);
        ipcMain.send('log', `Pobieranie ${type}: ${name} przerwane`);
      }
      return;
    }
    logger.error(`Błąd podczas pobierania ${type}: ${name}: ${e.message}`);
    if (!ipcMain.isDestroyed()) {
      ipcMain.send('modal', `Błąd podczas pobierania ${type}: ${name}: ${e.message}`);
      ipcMain.send('log', `Błąd ${type}: ${name}: ${e.message}`);
    }
    throw e;
  }
}

module.exports = { checkAssets, checkLibraries, checkManifest, checkVersions, checkAll, getArchive, downloadItemHandler };