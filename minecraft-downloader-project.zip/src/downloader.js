const { fetchManifest, fetchVersionManifest, downloadFile, logger } = require('./api');
const fs = require('fs-extra');
const path = require('path');

async function calculateAssetsTotals(manifest, signal) {
  let totalFiles = 0;
  let totalMb = 0;

  const assetsPath = path.join(__dirname, '../minecraft/assets');
  logger.info(`Zapewnianie folderu assets: ${assetsPath}`);
  await fs.ensureDir(assetsPath);

  for (const version of manifest.versions) {
    logger.info(`Obliczanie assetsów dla wersji ${version.id}`);
    const versionManifest = await fetchVersionManifest(version.id, signal);
    const assetIndex = versionManifest.assetIndex;
    totalMb += assetIndex.size / (1024 * 1024);
    totalFiles += assetIndex.totalSize ? 1 : 0;

    const assetIndexPath = path.join(assetsPath, 'indexes', `${assetIndex.id}.json`);
    logger.info(`Sprawdzanie assetIndex: ${assetIndexPath}`);
    if (!await fs.pathExists(assetIndexPath)) {
      logger.info(`Pobieranie assetIndex dla wersji ${version.id}`);
      await downloadFile(assetIndex.url, assetIndexPath, assetIndex.sha1, signal);
    }
    const assetIndexData = await fs.readJson(assetIndexPath);
    for (const [key, asset] of Object.entries(assetIndexData.objects)) {
      totalMb += asset.size / (1024 * 1024);
      totalFiles++;
    }
  }
  logger.info(`Obliczono: ${totalFiles} plików, ${totalMb.toFixed(1)} MB`);
  return { totalFiles, totalMb };
}

async function downloadAssets(emitProgress, signal) {
  logger.info('Rozpoczęcie pobierania assetsów...');
  try {
    const manifest = await fetchManifest(signal);
    const { totalFiles, totalMb } = await calculateAssetsTotals(manifest, signal);
    let downloadedFiles = 0;
    let downloadedMb = 0;
    let lastUpdate = Date.now();
    let bytesSinceLastUpdate = 0;

    const assetsPath = path.join(__dirname, '../minecraft/assets');
    logger.info(`Zapewnianie folderu assets: ${assetsPath}`);
    await fs.ensureDir(assetsPath);

    for (const version of manifest.versions) {
      logger.info(`Przetwarzanie assetsów dla wersji ${version.id}`);
      const versionManifest = await fetchVersionManifest(version.id, signal);
      const assetIndex = versionManifest.assetIndex;
      const assetIndexPath = path.join(assetsPath, 'indexes', `${assetIndex.id}.json`);
      logger.info(`Sprawdzanie assetIndex: ${assetIndexPath}`);
      if (!await fs.pathExists(assetIndexPath)) {
        const startTime = Date.now();
        logger.info(`Pobieranie assetIndex dla wersji ${version.id}`);
        await downloadFile(assetIndex.url, assetIndexPath, assetIndex.sha1, signal);
        const elapsed = (Date.now() - startTime) / 1000 || 0.001;
        downloadedFiles++;
        downloadedMb += assetIndex.size / (1024 * 1024);
        bytesSinceLastUpdate += assetIndex.size;
        logger.info(`Pobrano assetIndex: ${assetIndexPath}`);
      }

      const assetIndexData = await fs.readJson(assetIndexPath);
      logger.info(`Załadowano assetIndex z ${Object.keys(assetIndexData.objects).length} assetsami`);
      for (const [key, asset] of Object.entries(assetIndexData.objects)) {
        signal.throwIfAborted(); // Sprawdzenie przerwania w pętli
        const assetPath = path.join(assetsPath, 'objects', asset.hash.slice(0, 2), asset.hash);
        logger.info(`Sprawdzanie assetu: ${assetPath}`);
        if (!await fs.pathExists(assetPath)) {
          const startTime = Date.now();
          logger.info(`Pobieranie assetu: ${asset.hash}`);
          await downloadFile(`https://resources.download.minecraft.net/${asset.hash.slice(0, 2)}/${asset.hash}`, assetPath, asset.hash, signal);
          const elapsed = (Date.now() - startTime) / 1000 || 0.001;
          downloadedMb += asset.size / (1024 * 1024);
          bytesSinceLastUpdate += asset.size;
          downloadedFiles++;
          logger.info(`Pobrano asset: ${asset.hash}`);
        }

        const now = Date.now();
        if (now - lastUpdate >= 500) {
          const timeDiff = (now - lastUpdate) / 1000;
          const speed = (bytesSinceLastUpdate / (1024 * 1024)) / timeDiff;
          emitProgress('assets', (downloadedFiles / totalFiles) * 100, downloadedMb, totalMb, downloadedFiles, totalFiles, speed);
          logger.info(`Assets: ${downloadedMb.toFixed(1)}/${totalMb.toFixed(1)} MB, ${downloadedFiles}/${totalFiles} plików, ${speed.toFixed(1)} MB/s`);
          bytesSinceLastUpdate = 0;
          lastUpdate = now;
        }
      }
    }
    emitProgress('assets', 100, downloadedMb, totalMb, downloadedFiles, totalFiles, 0);
    logger.info(`Pobieranie assetsów zakończone, pobrano ${downloadedFiles} plików, ${downloadedMb.toFixed(1)} MB`);
  } catch (e) {
    if (e.message.includes('Przerwano')) {
      logger.info('Pobieranie assetsów przerwane');
      throw e;
    }
    throw e;
  }
}

async function calculateLibrariesTotals(manifest, signal) {
  let totalFiles = 0;
  let totalMb = 0;

  const librariesPath = path.join(__dirname, '../minecraft/libraries');
  logger.info(`Zapewnianie folderu bibliotek: ${librariesPath}`);
  await fs.ensureDir(librariesPath);

  for (const version of manifest.versions) {
    const versionManifest = await fetchVersionManifest(version.id, signal);
    for (const lib of versionManifest.libraries) {
      if (lib.downloads && lib.downloads.artifact) {
        totalMb += lib.downloads.artifact.size / (1024 * 1024);
        totalFiles++;
      }
    }
  }
  logger.info(`Obliczono: ${totalFiles} bibliotek, ${totalMb.toFixed(1)} MB`);
  return { totalFiles, totalMb };
}

async function downloadLibraries(emitProgress, signal) {
  logger.info('Rozpoczęcie pobierania bibliotek...');
  try {
    const manifest = await fetchManifest(signal);
    const { totalFiles, totalMb } = await calculateLibrariesTotals(manifest, signal);
    let downloadedFiles = 0;
    let downloadedMb = 0;
    let lastUpdate = Date.now();
    let bytesSinceLastUpdate = 0;

    const librariesPath = path.join(__dirname, '../minecraft/libraries');
    logger.info(`Zapewnianie folderu bibliotek: ${librariesPath}`);
    await fs.ensureDir(librariesPath);

    for (const version of manifest.versions) {
      const versionManifest = await fetchVersionManifest(version.id, signal);
      for (const lib of versionManifest.libraries) {
        signal.throwIfAborted(); // Sprawdzenie przerwania w pętli
        if (lib.downloads && lib.downloads.artifact) {
          const libPath = path.join(librariesPath, lib.downloads.artifact.path);
          logger.info(`Sprawdzanie biblioteki: ${libPath}`);
          if (!await fs.pathExists(libPath)) {
            const startTime = Date.now();
            logger.info(`Pobieranie biblioteki: ${lib.downloads.artifact.path}`);
            await downloadFile(lib.downloads.artifact.url, libPath, lib.downloads.artifact.sha1, signal);
            const elapsed = (Date.now() - startTime) / 1000 || 0.001;
            downloadedMb += lib.downloads.artifact.size / (1024 * 1024);
            bytesSinceLastUpdate += lib.downloads.artifact.size;
            downloadedFiles++;
            logger.info(`Pobrano bibliotekę: ${lib.downloads.artifact.path}`);
          }
          const now = Date.now();
          if (now - lastUpdate >= 500) {
            const timeDiff = (now - lastUpdate) / 1000;
            const speed = (bytesSinceLastUpdate / (1024 * 1024)) / timeDiff;
            emitProgress('libraries', (downloadedFiles / totalFiles) * 100, downloadedMb, totalMb, downloadedFiles, totalFiles, speed);
            logger.info(`Biblioteki: ${downloadedMb.toFixed(1)}/${totalMb.toFixed(1)} MB, ${downloadedFiles}/${totalFiles} plików, ${speed.toFixed(1)} MB/s`);
            bytesSinceLastUpdate = 0;
            lastUpdate = now;
          }
        }
      }
    }
    emitProgress('libraries', 100, downloadedMb, totalMb, downloadedFiles, totalFiles, 0);
    logger.info(`Pobieranie bibliotek zakończone, pobrano ${downloadedFiles} plików, ${downloadedMb.toFixed(1)} MB`);
  } catch (e) {
    if (e.message.includes('Przerwano')) {
      logger.info('Pobieranie bibliotek przerwane');
      throw e;
    }
    throw e;
  }
}

async function calculateVersionsTotals(manifest, signal) {
  let totalFiles = manifest.versions.length;
  let totalMb = 0;

  const versionsPath = path.join(__dirname, '../minecraft/versions');
  logger.info(`Zapewnianie folderu wersji: ${versionsPath}`);
  await fs.ensureDir(versionsPath);

  for (const version of manifest.versions) {
    const versionManifest = await fetchVersionManifest(version.id, signal);
    totalMb += versionManifest.downloads.client.size / (1024 * 1024);
  }
  logger.info(`Obliczono: ${totalFiles} wersji, ${totalMb.toFixed(1)} MB`);
  return { totalFiles, totalMb };
}

async function downloadVersions(emitProgress, signal) {
  logger.info('Rozpoczęcie pobierania wersji...');
  try {
    const manifest = await fetchManifest(signal);
    const { totalFiles, totalMb } = await calculateVersionsTotals(manifest, signal);
    let downloadedFiles = 0;
    let downloadedMb = 0;
    let lastUpdate = Date.now();
    let bytesSinceLastUpdate = 0;

    const versionsPath = path.join(__dirname, '../minecraft/versions');
    logger.info(`Zapewnianie folderu wersji: ${versionsPath}`);
    await fs.ensureDir(versionsPath);

    for (const version of manifest.versions) {
      signal.throwIfAborted(); // Sprawdzenie przerwania w pętli
      const versionDir = path.join(versionsPath, version.id);
      logger.info(`Zapewnianie folderu wersji: ${versionDir}`);
      await fs.ensureDir(versionDir);
      const versionPath = path.join(versionDir, `${version.id}.json`);
      const startTime = Date.now();
      logger.info(`Pobieranie manifestu wersji: ${version.id}`);
      await downloadFile(version.url, versionPath, null, signal);
      const elapsed = (Date.now() - startTime) / 1000 || 0.001;
      downloadedFiles++;
      const jarPath = path.join(versionDir, `${version.id}.jar`);
      const versionManifest = await fetchVersionManifest(version.id, signal);
      const jarStartTime = Date.now();
      logger.info(`Pobieranie pliku JAR wersji: ${version.id}`);
      await downloadFile(versionManifest.downloads.client.url, jarPath, versionManifest.downloads.client.sha1, signal);
      const jarElapsed = (Date.now() - jarStartTime) / 1000 || 0.001;
      downloadedMb += versionManifest.downloads.client.size / (1024 * 1024);
      bytesSinceLastUpdate += versionManifest.downloads.client.size;
      logger.info(`Pobrano wersję: ${version.id}`);
      const now = Date.now();
      if (now - lastUpdate >= 500) {
        const timeDiff = (now - lastUpdate) / 1000;
        const speed = (bytesSinceLastUpdate / (1024 * 1024)) / timeDiff;
        emitProgress('versions', (downloadedFiles / totalFiles) * 100, downloadedMb, totalMb, downloadedFiles, totalFiles, speed);
        logger.info(`Wersje: ${downloadedMb.toFixed(1)}/${totalMb.toFixed(1)} MB, ${downloadedFiles}/${totalFiles} plików, ${speed.toFixed(1)} MB/s`);
        bytesSinceLastUpdate = 0;
        lastUpdate = now;
      }
    }
    emitProgress('versions', 100, downloadedMb, totalMb, downloadedFiles, totalFiles, 0);
    logger.info(`Pobieranie wersji zakończone, pobrano ${downloadedFiles} plików, ${downloadedMb.toFixed(1)} MB`);
  } catch (e) {
    if (e.message.includes('Przerwano')) {
      logger.info('Pobieranie wersji przerwane');
      throw e;
    }
    throw e;
  }
}

async function downloadItem(type, name, emitProgress, signal) {
  logger.info(`Rozpoczęcie pobierania ${type}: ${name}`);
  try {
    let downloadedMb = 0;
    let totalMb = 0;
    let downloadedFiles = 0;
    let totalFiles = 1;
    let lastUpdate = Date.now();
    let bytesSinceLastUpdate = 0;

    if (type === 'version') {
      const versionManifest = await fetchVersionManifest(name, signal);
      totalMb = versionManifest.downloads.client.size / (1024 * 1024);
      const versionDir = path.join(__dirname, '../minecraft/versions', name);
      logger.info(`Zapewnianie folderu wersji: ${versionDir}`);
      await fs.ensureDir(versionDir);
      const versionPath = path.join(versionDir, `${name}.json`);
      logger.info(`Pobieranie manifestu wersji: ${name}`);
      await downloadFile(versionManifest.url, versionPath, null, signal);
      const jarPath = path.join(versionDir, `${name}.jar`);
      const startTime = Date.now();
      logger.info(`Pobieranie pliku JAR wersji: ${name}`);
      await downloadFile(versionManifest.downloads.client.url, jarPath, versionManifest.downloads.client.sha1, signal);
      const elapsed = (Date.now() - startTime) / 1000 || 0.001;
      downloadedMb += versionManifest.downloads.client.size / (1024 * 1024);
      bytesSinceLastUpdate += versionManifest.downloads.client.size;
      downloadedFiles++;
      logger.info(`Pobrano wersję: ${name}`);
    } else if (type === 'library') {
      const manifest = await fetchManifest(signal);
      const librariesPath = path.join(__dirname, '../minecraft/libraries');
      logger.info(`Zapewnianie folderu bibliotek: ${librariesPath}`);
      await fs.ensureDir(librariesPath);
      for (const version of manifest.versions) {
        const versionManifest = await fetchVersionManifest(version.id, signal);
        const lib = versionManifest.libraries.find(l => l.downloads?.artifact?.path?.includes(name));
        if (lib) {
          totalMb = lib.downloads.artifact.size / (1024 * 1024);
          const libPath = path.join(librariesPath, lib.downloads.artifact.path);
          const startTime = Date.now();
          logger.info(`Pobieranie biblioteki: ${lib.downloads.artifact.path}`);
          await downloadFile(lib.downloads.artifact.url, libPath, lib.downloads.artifact.sha1, signal);
          const elapsed = (Date.now() - startTime) / 1000 || 0.001;
          downloadedMb += lib.downloads.artifact.size / (1024 * 1024);
          bytesSinceLastUpdate += lib.downloads.artifact.size;
          downloadedFiles++;
          logger.info(`Pobrano bibliotekę: ${name}`);
          break;
        }
      }
    } else if (type === 'asset') {
      totalMb = 0.1; // Przybliżony rozmiar
      const assetsPath = path.join(__dirname, '../minecraft/assets');
      logger.info(`Zapewnianie folderu assets: ${assetsPath}`);
      await fs.ensureDir(assetsPath);
      const assetPath = path.join(assetsPath, 'objects', name.slice(0, 2), name);
      const startTime = Date.now();
      logger.info(`Pobieranie assetu: ${name}`);
      await downloadFile(`https://resources.download.minecraft.net/${name.slice(0, 2)}/${name}`, assetPath, name, signal);
      const elapsed = (Date.now() - startTime) / 1000 || 0.001;
      downloadedMb += 0.1;
      bytesSinceLastUpdate += 0.1 * 1024 * 1024;
      downloadedFiles++;
      logger.info(`Pobrano asset: ${name}`);
    }

    const timeDiff = (Date.now() - lastUpdate) / 1000 || 0.001;
    const speed = (bytesSinceLastUpdate / (1024 * 1024)) / timeDiff;
    emitProgress(type, 100, downloadedMb, totalMb, downloadedFiles, totalFiles, speed);
    logger.info(`${type}: ${downloadedMb.toFixed(1)}/${totalMb.toFixed(1)} MB, ${downloadedFiles}/${totalFiles} plików, ${speed.toFixed(1)} MB/s`);
  } catch (e) {
    if (e.message.includes('Przerwano')) {
      logger.info(`Pobieranie ${type}: ${name} przerwane`);
      throw e;
    }
    throw e;
  }
}

module.exports = { downloadAssets, downloadLibraries, downloadVersions, downloadItem };