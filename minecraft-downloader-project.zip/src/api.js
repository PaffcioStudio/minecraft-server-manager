const axios = require('axios');
const path = require('path');
const fs = require('fs-extra');
const winston = require('winston');

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ timestamp, level, message }) => `${timestamp} ${level}: ${message}`)
  ),
  transports: [
    new winston.transports.File({ filename: path.join(__dirname, '../logs/app.log') }),
    new winston.transports.Console()
  ]
});

async function fetchManifest(signal) {
  logger.info('Pobieranie manifestu wersji z API Mojanga...');
  try {
    const url = 'https://launchermeta.mojang.com/mc/game/version_manifest.json';
    const res = await axios.get(url, { signal });
    const manifestPath = path.join(__dirname, '../minecraft');
    logger.info(`Zapisywanie manifestu do: ${manifestPath}/manifest.json`);
    await fs.ensureDir(manifestPath);
    await fs.writeJson(path.join(manifestPath, 'manifest.json'), res.data, { spaces: 2 });
    logger.info('Manifest wersji zapisany pomyślnie');
    return res.data;
  } catch (e) {
    if (e.name === 'AbortError') {
      logger.info('Pobieranie manifestu przerwane');
      throw new Error('Przerwano pobieranie manifestu');
    }
    logger.error(`Błąd pobierania manifestu: ${e.message}`);
    throw new Error(`Nie udało się pobrać manifestu: ${e.message}`);
  }
}

async function fetchVersionManifest(versionId, signal) {
  logger.info(`Pobieranie manifestu wersji ${versionId}...`);
  try {
    const manifest = await fetchManifest(signal);
    const version = manifest.versions.find(v => v.id === versionId);
    if (!version) {
      logger.error(`Wersja ${versionId} nie istnieje`);
      throw new Error(`Wersja ${versionId} nie istnieje`);
    }
    const res = await axios.get(version.url, { signal });
    const versionPath = path.join(__dirname, '../minecraft/versions', versionId);
    logger.info(`Zapisywanie manifestu wersji ${versionId} do: ${versionPath}/${versionId}.json`);
    await fs.ensureDir(versionPath);
    await fs.writeJson(path.join(versionPath, `${versionId}.json`), res.data, { spaces: 2 });
    logger.info(`Manifest wersji ${versionId} pobrany i zapisany pomyślnie`);
    return res.data;
  } catch (e) {
    if (e.name === 'AbortError') {
      logger.info(`Pobieranie manifestu wersji ${versionId} przerwane`);
      throw new Error(`Przerwano pobieranie manifestu wersji ${versionId}`);
    }
    logger.error(`Błąd pobierania manifestu wersji ${versionId}: ${e.message}`);
    throw new Error(`Nie udało się pobrać manifestu wersji ${versionId}: ${e.message}`);
  }
}

async function downloadFile(url, dest, sha1, signal) {
  logger.info(`Pobieranie pliku z ${url} do ${dest}...`);
  try {
    const res = await axios.get(url, { responseType: 'arraybuffer', signal });
    if (sha1) {
      const crypto = require('crypto');
      const hash = crypto.createHash('sha1').update(res.data).digest('hex');
      if (hash !== sha1) {
        logger.error(`Błąd weryfikacji SHA1 dla ${url}: oczekiwano ${sha1}, otrzymano ${hash}`);
        throw new Error(`Błąd SHA1 dla ${url}`);
      }
      logger.info(`Weryfikacja SHA1 dla ${url} zakończona pomyślnie`);
    }
    await fs.ensureDir(path.dirname(dest));
    await fs.outputFile(dest, res.data);
    logger.info(`Plik zapisany w ${dest}`);
  } catch (e) {
    if (e.name === 'AbortError') {
      logger.info(`Pobieranie pliku ${url} przerwane`);
      throw new Error(`Przerwano pobieranie pliku ${url}`);
    }
    logger.error(`Błąd pobierania/zapisu pliku ${url} do ${dest}: ${e.message}`);
    throw new Error(`Nie udało się pobrać/zapisać pliku ${url}: ${e.message}`);
  }
}

module.exports = { fetchManifest, fetchVersionManifest, downloadFile, logger };