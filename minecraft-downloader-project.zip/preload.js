const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('ipcRenderer', {
  send: (channel, ...data) => {
    const validChannels = [
      'check-assets',
      'check-libraries',
      'check-manifest',
      'check-versions',
      'check-all',
      'get-archive',
      'download-item',
      'update-settings',
      'stop',
      'export-to-zip',
      'import-from-zip',
      'clear-logs'
    ];
    if (validChannels.includes(channel)) {
      ipcRenderer.send(channel, ...data);
    }
  },
  on: (channel, func) => {
    const validChannels = [
      'progress',
      'archive',
      'modal',
      'log',
      'assets-summary',
      'backup-progress'
    ];
    if (validChannels.includes(channel)) {
      ipcRenderer.on(channel, (event, ...args) => func(event, ...args));
    }
  },
  invoke: (channel, data) => {
    const validChannels = [
      'get-settings',
      'get-stats',
      'get-translations'
    ];
    if (validChannels.includes(channel)) {
      return ipcRenderer.invoke(channel, data);
    }
  }
});